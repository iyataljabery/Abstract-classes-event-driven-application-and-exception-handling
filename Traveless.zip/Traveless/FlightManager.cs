﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

public class FlightManager
{
    private List<Flight> _flights = new List<Flight>();

    public void LoadFlights(string filePath)
    {
        var lines = File.ReadAllLines(filePath);
        foreach (var line in lines.Skip(1)) // Header gets skipped
        {
            var data = line.Split(',');
            _flights.Add(new Flight
            {
                FlightCode = data[0],
                Airline = data[1],
                Origin = data[2],
                Destination = data[3],
                Day = data[4],
                Time = data[5],
                Cost = decimal.Parse(data[6]),
                AvailableSeats = int.Parse(data[7])
            });
        }
    }

    public List<Flight> FindFlights(string origin, string destination, string day)
    {
        return _flights.FindAll(f =>
            f.Origin.Equals(origin, StringComparison.OrdinalIgnoreCase) &&
            f.Destination.Equals(destination, StringComparison.OrdinalIgnoreCase) &&
            f.Day.Equals(day, StringComparison.OrdinalIgnoreCase)
        );
    }
}