﻿class Program
{
    static void Main(string[] args)
    {
        var flightManager = new FlightManager();
        flightManager.LoadFlights("flights.csv");

        var flights = flightManager.FindFlights("YYC", "YVR", "Monday");
        foreach (var flight in flights)
        {
            Console.WriteLine(flight);
        }

        var reservationManager = new ReservationManager();
        var reservation = reservationManager.MakeReservation(flights[0], "John Doe", "Canadian");
        Console.WriteLine($"Reservation made: {reservation}");

        var foundReservations = reservationManager.FindReservations(reservationCode: reservation.ReservationCode);
        foreach (var res in foundReservations)
        {
            Console.WriteLine($"Found reservation: {res}");
        }
    }
}