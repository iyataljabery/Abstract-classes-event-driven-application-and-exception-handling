﻿using System;

public class Flight
{
    public string FlightCode { get; set; }
    public string Airline { get; set; }
    public string Origin { get; set; }
    public string Destination { get; set; }
    public string Day { get; set; }
    public string Time { get; set; }
    public decimal Cost { get; set; }
    public int AvailableSeats { get; set; }

    public override string ToString()
    {
        return $"{FlightCode} | {Airline} | {Origin} -> {Destination} | {Day} {Time} | ${Cost} | Seats: {AvailableSeats}";
    }
}