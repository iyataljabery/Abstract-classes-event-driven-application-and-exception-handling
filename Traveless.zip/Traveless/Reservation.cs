﻿using System;

public class Reservation
{
    public string ReservationCode { get; set; }
    public Flight Flight { get; set; }
    public string TravelerName { get; set; }
    public string Citizenship { get; set; }
    public bool IsActive { get; set; } = true;

    public override string ToString()
    {
        return $"{ReservationCode} | {Flight.FlightCode} | {TravelerName} | {Citizenship} | Status: {(IsActive ? "Active" : "Inactive")}";
    }
}