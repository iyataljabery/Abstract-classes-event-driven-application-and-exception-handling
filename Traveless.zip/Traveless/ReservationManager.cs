﻿using System;
using System.Collections.Generic;
using System.IO;

public class ReservationManager
{
    private List<Reservation> _reservations = new List<Reservation>();
    private const string ReservationFilePath = "reservations.dat";

    public Reservation MakeReservation(Flight flight, string travelerName, string citizenship)
    {
        if (flight == null || string.IsNullOrEmpty(travelerName) || string.IsNullOrEmpty(citizenship))
        {
            throw new ArgumentException("Flight, traveler name, and citizenship cannot be null or empty.");
        }

        if (flight.AvailableSeats <= 0)
        {
            throw new InvalidOperationException("No available seats on this flight.");
        }

        string reservationCode = GenerateReservationCode();
        var reservation = new Reservation
        {
            ReservationCode = reservationCode,
            Flight = flight,
            TravelerName = travelerName,
            Citizenship = citizenship
        };

        _reservations.Add(reservation);
        flight.AvailableSeats--; // Reduces seat availablity
        PersistReservations();

        return reservation;
    }

    public List<Reservation> FindReservations(string reservationCode = null, string airline = null, string travelerName = null)
    {
        return _reservations.FindAll(r =>
            (string.IsNullOrEmpty(reservationCode) || r.ReservationCode.Equals(reservationCode, StringComparison.OrdinalIgnoreCase)) &&
            (string.IsNullOrEmpty(airline) || r.Flight.Airline.Equals(airline, StringComparison.OrdinalIgnoreCase)) &&
            (string.IsNullOrEmpty(travelerName) || r.TravelerName.Equals(travelerName, StringComparison.OrdinalIgnoreCase))
        );
    }

    public void UpdateReservation(string reservationCode, string newTravelerName, string newCitizenship, bool isActive)
    {
        var reservation = _reservations.Find(r => r.ReservationCode.Equals(reservationCode, StringComparison.OrdinalIgnoreCase));
        if (reservation == null)
        {
            throw new ArgumentException("Reservation not found.");
        }

        reservation.TravelerName = newTravelerName;
        reservation.Citizenship = newCitizenship;
        reservation.IsActive = isActive;
        PersistReservations();
    }

    private string GenerateReservationCode()
    {
        Random random = new Random();
        char letter = (char)('A' + random.Next(0, 26));
        string digits = random.Next(1000, 9999).ToString();
        return $"{letter}{digits}";
    }

    private void PersistReservations()
    {
        using (FileStream stream = new FileStream(ReservationFilePath, FileMode.Create))
        {
            var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            formatter.Serialize(stream, _reservations);
        }
    }

    public void LoadReservations()
    {
        if (File.Exists(ReservationFilePath))
        {
            using (FileStream stream = new FileStream(ReservationFilePath, FileMode.Open))
            {
                var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                _reservations = (List<Reservation>)formatter.Deserialize(stream);
            }
        }
    }
}